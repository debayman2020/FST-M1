package liveproject;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class keepproject2 {
    AndroidDriver<MobileElement> driver;


    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.google.android.keep");
        caps.setCapability("appActivity", ".activities.BrowseActivity");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }
    
    @Test
    public void keeptask(){
        WebDriverWait wait = new WebDriverWait(driver,5);
        wait.until(ExpectedConditions.elementToBeClickable(MobileBy.xpath("//android.widget.ImageButton[@content-desc = 'New text note']")));
        driver.findElementByAccessibilityId("New text note").click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(MobileBy.xpath("//android.widget.EditText[@text = 'Title']")));
        driver.findElementByXPath("//android.widget.EditText[@text = 'Title']").sendKeys("Project2 Title");
        driver.findElementByXPath("//android.widget.EditText[@text = 'Note']").sendKeys("This is a test description for Appium");
        driver.findElementByAccessibilityId("Open navigation drawer").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.TextView[@text = 'Project2 Title']")));
        String text = driver.findElementByXPath("//android.widget.TextView[@text = 'Project2 Title']").getText();
        Assert.assertEquals(text,"Project2 Title");


    }

    @AfterClass
    public void teardown(){
        //close the app
        driver.quit();
    }
}
