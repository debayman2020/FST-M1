package liveproject;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class taskproject1 {
    AndroidDriver<MobileElement> driver;

    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.google.android.apps.tasks");
        caps.setCapability("appActivity", ".ui.TaskListsActivity");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }

    @Test
    public void task(){
        WebDriverWait wait = new WebDriverWait(driver,5);
        wait.until(ExpectedConditions.elementToBeClickable(MobileBy.xpath("//android.widget.ImageButton[@content-desc = 'Create new task']")));
        driver.findElementByAccessibilityId("Create new task").click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(MobileBy.xpath("//android.widget.EditText[@text = 'New task']")));
        driver.findElementByXPath("//android.widget.EditText[@text = 'New task']").sendKeys("Complete Activity with Google Tasks");
        driver.findElementById("add_task_done").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.TextView[@text = 'Complete Activity with Google Tasks']")));
        String task1 = driver.findElementByXPath("//android.widget.TextView[@text = 'Complete Activity with Google Tasks']").getText();
        Assert.assertEquals(task1,"Complete Activity with Google Tasks");

    }

    @Test
    public void keep(){
        WebDriverWait wait = new WebDriverWait(driver,5);
        wait.until(ExpectedConditions.elementToBeClickable(driver.findElementByAccessibilityId("Create new task")));
        driver.findElementByAccessibilityId("Create new task").click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(MobileBy.xpath("//android.widget.EditText[@text = 'New task']")));
        driver.findElementByXPath("//android.widget.EditText[@text = 'New task']").sendKeys("Complete Activity with Google Keep");
        driver.findElementById("add_task_done").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.TextView[@text = 'Complete Activity with Google Keep']")));
        String task2 = driver.findElementByXPath("//android.widget.TextView[@text = 'Complete Activity with Google Keep']").getText();
        Assert.assertEquals(task2,"Complete Activity with Google Keep");

    }

    @Test
    public void keepSecond(){
        WebDriverWait wait = new WebDriverWait(driver,5);
        wait.until(ExpectedConditions.elementToBeClickable(driver.findElementByAccessibilityId("Create new task")));
        driver.findElementByAccessibilityId("Create new task").click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(MobileBy.xpath("//android.widget.EditText[@text = 'New task']")));
        driver.findElementByXPath("//android.widget.EditText[@text = 'New task']").sendKeys("Complete the second Activity Google Keep");
        driver.findElementById("add_task_done").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.TextView[@text = 'Complete the second Activity Google Keep']")));
        String task3 = driver.findElementByXPath("//android.widget.TextView[@text = 'Complete the second Activity Google Keep']").getText();
        Assert.assertEquals(task3,"Complete the second Activity Google Keep");

    }

    @AfterClass
    public void teardown(){
        //close the app
        driver.quit();
    }
}
