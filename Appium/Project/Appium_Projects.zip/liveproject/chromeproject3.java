package liveproject;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class chromeproject3 {
    AndroidDriver<MobileElement> driver;

    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.android.chrome");
        caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }

    @Test
    public void chrometask(){
        WebDriverWait wait = new WebDriverWait(driver,5);
        driver.get("https://www.training-support.net/selenium");
        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.TextView[@text = 'Selenium']")));
        driver.findElement(MobileBy.AndroidUIAutomator("UiScrollable(UiSelector().scrollable(true)).scrollForward(7).scrollIntoView(text(\"To-Do List\"))"));
        driver.findElementByXPath("//android.widget.TextView[@text = 'To-Do List']").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.EditText[@resource-id = 'taskInput']")));
        driver.findElementByXPath("//android.widget.EditText[@resource-id = 'taskInput']").sendKeys("Add tasks to list");
        driver.findElementByXPath("//android.widget.Button[@text = 'Add Task']").click();
        driver.findElementByXPath("//android.widget.EditText[@resource-id = 'taskInput']").sendKeys("Get number of tasks");
        driver.findElementByXPath("//android.widget.Button[@text = 'Add Task']").click();
        driver.findElementByXPath("//android.widget.EditText[@resource-id = 'taskInput']").sendKeys("Clear the list");
        driver.findElementByXPath("//android.widget.Button[@text = 'Add Task']").click();
        driver.findElementByXPath("//android.widget.TextView[@text = 'Add tasks to list']").click();
        driver.findElementByXPath("//android.widget.TextView[@text = 'Get number of tasks']").click();
        driver.findElementByXPath("//android.widget.TextView[@text = 'Clear the list']").click();
        Assert.assertEquals(driver.findElementByXPath("//android.widget.TextView[@text = 'Add tasks to list']").getText(),"Add tasks to list");
        driver.findElementByXPath("//android.widget.TextView[@text = 'Clear List']").click();
    }

    @AfterClass
    public void teardown(){
        //close the app
        driver.quit();
    }
}
