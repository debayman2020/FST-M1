package Activities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class activity3 {

    AndroidDriver<MobileElement> driver;

    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.sec.android.app.popupcalculator");
        caps.setCapability("appActivity", ".Calculator");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }

    @Test
    public void addition(){
        driver.findElementById("calc_keypad_btn_05").click();
        driver.findElementByAccessibilityId("Plus").click();
        driver.findElementById("calc_keypad_btn_09").click();
        driver.findElementByAccessibilityId("Equal").click();
        String Result = driver.findElementById("calc_edt_formula").getText();
        Assert.assertEquals(Result,"14");
        System.out.println("5+9="+Result);

    }

    @Test
    public void substract(){
        driver.findElementById("calc_keypad_btn_01").click();
        driver.findElementById("calc_keypad_btn_00").click();
        driver.findElementByAccessibilityId("Minus").click();
        driver.findElementById("calc_keypad_btn_05").click();
        driver.findElementByAccessibilityId("Equal").click();
        String Result = driver.findElementById("calc_edt_formula").getText();
        Assert.assertEquals(Result,"5");
        System.out.println("10-5="+Result);

    }
    @Test
    public void multiplication(){
        driver.findElementById("calc_keypad_btn_05").click();
        driver.findElementByAccessibilityId("Multiplication").click();
        driver.findElementById("calc_keypad_btn_01").click();
        driver.findElementById("calc_keypad_btn_00").click();
        driver.findElementById("calc_keypad_btn_00").click();
        driver.findElementByAccessibilityId("Equal").click();
        String Result = driver.findElementById("calc_edt_formula").getText();
        Assert.assertEquals(Result,"500");
        System.out.println("5*100="+Result);

    }
    @Test
    public void divide(){
        driver.findElementById("calc_keypad_btn_05").click();
        driver.findElementById("calc_keypad_btn_00").click();
        driver.findElementByAccessibilityId("Division").click();
        driver.findElementById("calc_keypad_btn_02").click();
        driver.findElementByAccessibilityId("Equal").click();
        String Result = driver.findElementById("calc_edt_formula").getText();
        Assert.assertEquals(Result,"25");
        System.out.println("50/2="+Result);

    }

    @AfterClass
    public void teardown(){
        driver.quit();
    }

}
