package Activities;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class activity4 {
    AndroidDriver<MobileElement> driver;

    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.samsung.android.app.contacts");
        caps.setCapability("appActivity", "com.samsung.android.contacts.contactslist.PeopleActivity");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }

    @Test
    public void addcontact(){
        driver.findElementById("menu_create_contact").click();
        WebDriverWait wait= new WebDriverWait(driver,5);
        wait.until(ExpectedConditions.elementToBeClickable(MobileBy.id("arrowButton")));
        driver.findElementByAccessibilityId("Show detailed name fields").click();
        driver.findElementById("firstEdit").sendKeys("Aaditya");
        driver.findElementById("lastEdit").sendKeys("Varma");
        driver.findElementByAccessibilityId("Hide detailed name fields").click();
        driver.findElementById("titleLayout").click();
        wait.until(ExpectedConditions.elementToBeClickable(MobileBy.id("phone_and_new_badge")));
        driver.findElementByXPath("//android.widget.EditText[@text = 'Phone']").sendKeys("9991284782");
        driver.findElementById("smallLabel").click();
        String number = driver.findElementById("display_number").getText();
        Assert.assertEquals(number,"9991284782");

    }

    @AfterClass
    public void teardown(){
        //close the app
        driver.quit();
    }
}
