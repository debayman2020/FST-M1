package Activities;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class activity5 {
    AndroidDriver<MobileElement> driver;

    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.samsung.android.messaging");
        caps.setCapability("appActivity", "com.android.mms.ui.ConversationComposer");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }

    @Test
    public void message(){
        driver.findElementByAccessibilityId("Compose new message").click();
        WebDriverWait wait= new WebDriverWait(driver,5);
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(MobileBy.id("recipients_editor_to"))));
        driver.findElementById("recipients_editor_to").sendKeys("8584039680");
        driver.findElementById("message_edit_text").sendKeys("Hello from Appium");
        driver.findElementByAccessibilityId("Send, Button").click();
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(MobileBy.id("content_text_view"))));
        String text = driver.findElementById("content_text_view").getText();
        Assert.assertEquals(text,"Hello from Appium");


    }

    @AfterClass
    public void teardown(){
        //close the app
        driver.quit();
    }
}
