package Activities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class activity1 {
    AndroidDriver<MobileElement> driver;

    @BeforeClass
    public void setup() throws MalformedURLException {
        //Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceId", "R9ZR101H4YY");
        caps.setCapability("platformName", "android");
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "com.sec.android.app.popupcalculator");
        caps.setCapability("appActivity", ".Calculator");
        caps.setCapability("noReset", true);

        //Appium Server URL
        URL serverURL = new URL("http://localhost:4723/wd/hub");

        //Driver Initialization
        driver = new AndroidDriver<>(serverURL,caps);

    }

    @Test
    public void multiplicationTest(){
        //Find 3 and click it
        driver.findElementById("calc_keypad_btn_03").click();
        //Find + and click it
        driver.findElementByAccessibilityId("Multiplication").click();
        //Find 3 and click it
        driver.findElementById("calc_keypad_btn_05").click();
        //Find = and click it
        driver.findElementByAccessibilityId("Equal").click();

        //Get result and print it
        String result = driver.findElementById("calc_edt_formula").getText();
        System.out.println("Result is: "+result);

        //Assertion
        Assert.assertEquals(result,"15");
    }

    @AfterClass
    public void teardown(){
        //close the app
        driver.quit();
    }
}
