P1 = input("Hey player1 enter your choice: ").lower()
P2 = input("Hey player2 enter your choice: ").lower()
if P1 == 'rock':
    if P2 == 'paper':
        print("player2 wins")
    elif P2 =='rock':
        print("tie")
    else:
        print("player1 wins")
elif P1== 'scissor':
    if P2 == 'paper':
        print("player1 wins")
    elif P2 =='scissor':
        print("tie")
    else:
        print("player2 wins")
else:
    if P2 == 'rock':
        print("player1 wins")
    elif P2 =='paper':
        print("tie")
    else:
        print("player2 wins")