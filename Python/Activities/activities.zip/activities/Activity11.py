fruit_shop = {
    "name" : ["apple","orange","banana"],
    "price" : ["1","2","3"]
}
a = input("Enter the name: ").lower()
if a in fruit_shop["name"]:
    print("yes")
else:
    print("no")