# Given list of numbers
numList = list(input("Enter a sequence of comma separated values: ").split())
print("Given list is ", numList)

# Get first element in list
firstElement = int(numList[0])
# Get last element in list
lastElement = int(numList[-1])

# Check if first and last element are equal
if (firstElement == lastElement):
    print(True)
else:
    print(False)