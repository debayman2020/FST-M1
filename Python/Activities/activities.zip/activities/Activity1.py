Age = input("Enter your age: ")
name = input("Enter you name: ")
age = int(Age)
cent = 100 - age
year = 2022+cent
Year = str(year)
print("Hi "+name+" on the year "+Year+" you will turn into 100 years old!")