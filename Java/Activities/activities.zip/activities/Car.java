package activities;

public class Car {
    String color;
    String transmission;
    int make;
    int tyres;
    int doors;

        Car() {
        tyres = 4;
        doors = 4;
    }

    public void displayCharacterstics(){
        System.out.println("Car color=" + color);
        System.out.println("Car make=" + make);
        System.out.println("Transmission mode of the Car=" + transmission);
        System.out.println("Doors on the car=" + doors);
        System.out.println("Tyres on the car=" + tyres);
    }

    public void accelerate() {
        System.out.println("Car is moving forward.");
    }

    public void brake() {
        System.out.println("Car has stopped.");
    }
}